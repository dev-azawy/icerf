import SwiftUI

struct StoreView: View {
    @EnvironmentObject var store: Store
    @State private var q = ""
    var filtered: [AppItem] { q.isEmpty ? store.apps : store.apps.filter { $0.name.localizedCaseInsensitiveContains(q) } }
    var body: some View {
        NavigationView {
            List(filtered) { app in
                HStack(spacing: 12) {
                    AsyncImage(url: URL(string: app.iconURL ?? "")) { $0.resizable() } placeholder: { Color.gray.opacity(0.2) }
                        .frame(width: 60, height: 60).clipShape(RoundedRectangle(cornerRadius: 14))
                    VStack(alignment: .leading) {
                        Text(app.name).font(.headline)
                        Text(app.category ?? app.version ?? "").font(.caption).foregroundColor(.secondary)
                    }
                    Spacer()
                    Button("تثبيت") { /* حمّل IPA ثم Signer.sign ثم ثبّت */ }
                        .buttonStyle(.borderedProminent).clipShape(Capsule())
                }
            }
            .searchable(text: $q).navigationTitle("التطبيقات")
        }
    }
}

struct SignView: View {
    var body: some View {
        NavigationView { Text("اختر IPA + شهادة .p12 + ملف .mobileprovision ثم وقّع").padding().navigationTitle("التوقيع") }
    }
}

struct SettingsView: View {
    @EnvironmentObject var store: Store
    @State private var url = ""
    var body: some View {
        NavigationView {
            Form {
                Section("إضافة مصدر") {
                    TextField("رابط JSON", text: $url).autocapitalization(.none)
                    Button("إضافة") { store.add(url); url = "" }
                }
                Section("المطور") {
                    Link("Instagram: eng_azawy", destination: URL(string: "https://instagram.com/eng_azawy")!)
                    Link("Telegram: bavarite", destination: URL(string: "https://t.me/bavarite")!)
                    Link("TikTok: eyesiq", destination: URL(string: "https://tiktok.com/@eyesiq")!)
                    Link("icerf.netlify.app", destination: URL(string: "https://icerf.netlify.app")!)
                }
                Section("تراخيص") { Text("يستخدم zsign (MIT) – zhlynn").font(.footnote) }
            }.navigationTitle("الإعدادات")
        }
    }
}
