import Foundation

enum Signer {
    /// يضيف .icerf لمعرف الحزمة حتى لا يتعارض مع تطبيقات App Store
    static func iCerfID(_ original: String) -> String {
        original.hasSuffix(".icerf") ? original : original + ".icerf"
    }

    static func sign(ipa: URL, p12: URL, password: String, profile: URL,
                     originalBundleID: String, out: URL) -> Bool {
        let args = ["zsign", "-k", p12.path, "-p", password, "-m", profile.path,
                    "-b", iCerfID(originalBundleID), "-o", out.path, ipa.path]
        var c: [UnsafeMutablePointer<CChar>?] = args.map { strdup($0) }
        defer { c.forEach { free($0) } }
        return zsign_main(Int32(c.count), &c) == 0
    }
}
