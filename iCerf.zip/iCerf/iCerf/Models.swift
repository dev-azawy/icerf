import Foundation

struct Source: Codable { var name: String?; var apps: [AppItem] }
struct AppItem: Codable, Identifiable {
    var id: String { bundleIdentifier + (version ?? "") }
    let name: String
    let bundleIdentifier: String
    var iconURL: String?
    var localizedDescription: String?
    var version: String?
    var downloadURL: String?
    var category: String?
}

@MainActor final class Store: ObservableObject {
    @Published var apps: [AppItem] = []
    @Published var sources: [String] = UserDefaults.standard.stringArray(forKey: "sources") ?? []

    func add(_ url: String) { sources.append(url); UserDefaults.standard.set(sources, forKey: "sources"); Task { await load() } }

    func load() async {
        var all: [AppItem] = []
        for s in sources {
            guard let u = URL(string: s),
                  let (d, _) = try? await URLSession.shared.data(from: u),
                  let src = try? JSONDecoder().decode(Source.self, from: d) else { continue }
            all += src.apps
        }
        apps = all
    }
}
