int zsign_main(int argc, char **argv);
