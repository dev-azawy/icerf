import SwiftUI

@main struct iCerfApp: App {
    @StateObject var store = Store()
    var body: some Scene {
        WindowGroup {
            TabView {
                StoreView().tabItem { Label("التطبيقات", systemImage: "square.stack.3d.up.fill") }
                SignView().tabItem { Label("التوقيع", systemImage: "signature") }
                SettingsView().tabItem { Label("الإعدادات", systemImage: "gearshape.fill") }
            }
            .environmentObject(store)
            .task { await store.load() }
        }
    }
}
